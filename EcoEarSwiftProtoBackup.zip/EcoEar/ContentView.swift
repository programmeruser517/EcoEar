//
//  ContentView.swift
//  EcoEar
//
//  Created by Peter Pena on 5/28/25.
//

import SwiftUI
import UserNotifications

struct ContentView: View {
    @Binding var appState: AppLifecycleState
    
    var body: some View {
        ZStack(alignment: .top) {
            Color.white.ignoresSafeArea()
            
            VStack(spacing: 0) {
                NotificationBanner(appState: appState)
                Spacer()
                Text("Empty app content. For now...").padding()
            }
        }
    }
}
