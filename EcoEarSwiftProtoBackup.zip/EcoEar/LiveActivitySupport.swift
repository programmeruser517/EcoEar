//
//  LiveActivitySupport.swift
//  EcoEar
//
//  Created by Peter Pena on 5/30/25.
//

import Foundation
import ActivityKit
import SwiftUI

/*
 * IMPORTANT: Live Activities Setup Guide
 * =====================================
 *
 * To enable Live Activities in your EcoEar app, you need to:
 *
 * 1. Add NSSupportsLiveActivities key to Info.plist:
 *    - Open your target settings in Xcode
 *    - Go to the "Info" tab
 *    - Add a new entry with key "NSSupportsLiveActivities" and type "Boolean" set to "YES"
 *
 * 2. Ensure your deployment target is iOS 16.1 or later:
 *    - Open your target settings in Xcode
 *    - Go to the "General" tab
 *    - Set "Minimum Deployments" to iOS 16.1 or later
 *
 * 3. Create a Widget Extension target for the Live Activity:
 *    - In Xcode, go to File > New > Target
 *    - Select "Widget Extension"
 *    - Make sure "Include Live Activity" is checked
 *    - Configure and add the target
 *
 * 4. If you want to extend the Live Activity duration (optional):
 *    - Add NSLiveActivityDuration key to Info.plist (8 hours is default, 12 is max)
 *    - Set it to a number (in hours, up to 12)
 *
 * Note: If you're seeing "Error starting Live Activity: The operation couldn't be completed. 
 * Target does not include NSSupportsLiveActivities plist key", you must complete step 1 above.
 */

/// Helper class for Live Activity management and error handling
class LiveActivitySupportHelper {
    
    /// Check if Live Activities are enabled in the app
    static func areLiveActivitiesEnabled() -> Bool {
        return ActivityAuthorizationInfo().areActivitiesEnabled
    }
    
    /// Verify Live Activities can be used and provide detailed error messages
    static func verifyLiveActivitiesSupport() -> (supported: Bool, errorMessage: String?) {
        // Check if running on iOS 16.1 or later
        if #available(iOS 16.1, *) {
            // Check if Live Activities are enabled in Info.plist
            if !ActivityAuthorizationInfo().areActivitiesEnabled {
                return (false, """
                    Live Activities are not enabled in this app.
                    
                    Please add NSSupportsLiveActivities=YES to your Info.plist file:
                    1. Open your target settings in Xcode
                    2. Go to the "Info" tab
                    3. Add a new entry with key "NSSupportsLiveActivities" and type "Boolean" set to "YES"
                    """)
            }
            
            return (true, nil)
        } else {
            return (false, """
                Live Activities require iOS 16.1 or later.
                
                Please update your deployment target:
                1. Open your target settings in Xcode
                2. Go to the "General" tab
                3. Set "Minimum Deployments" to iOS 16.1 or later
                """)
        }
    }
    
    /// Attempt to start a Live Activity with detailed error handling
    static func startActivityWithErrorHandling<T: ActivityAttributes>(
        attributes: T,
        contentState: T.ContentState,
        completion: @escaping (Result<Activity<T>, Error>) -> Void
    ) {
        let (supported, errorMessage) = verifyLiveActivitiesSupport()
        
        guard supported else {
            let error = NSError(
                domain: "LiveActivityError",
                code: 1,
                userInfo: [NSLocalizedDescriptionKey: errorMessage ?? "Live Activities not supported"]
            )
            completion(.failure(error))
            return
        }
        
        do {
            let activity = try Activity.request(
                attributes: attributes,
                contentState: contentState,
                pushType: nil
            )
            completion(.success(activity))
        } catch {
            completion(.failure(error))
        }
    }
}

