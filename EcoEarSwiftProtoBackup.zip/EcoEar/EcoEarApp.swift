//
//  EcoEarApp.swift
//  EcoEar
//
//  Created by Peter Pena on 5/28/25.
//

import SwiftUI
import UserNotifications
import UIKit
import ActivityKit

@main
struct EcoEarApp: App {
    @Environment(\.scenePhase) private var scenePhase
    @State private var appState: AppLifecycleState = .active
    private let liveActivityManager = LiveActivityManager()
    
    init() {
        // No need to register for remote notifications with Live Activities
    }
    
    var body: some Scene {
        WindowGroup {
            ContentView(appState: $appState)
                .onAppear {
                    // Start the Live Activity when app appears
                    liveActivityManager.startActivity(state: appState)
                }
                .onDisappear {
                    // End the Live Activity when app is closed
                    liveActivityManager.endActivity()
                }
            .onChange(of: scenePhase) { newPhase in
                switch newPhase {
                case .active:
                    appState = .active
                    liveActivityManager.updateActivity(state: .active)
                case .inactive:
                    appState = .inactive
                    liveActivityManager.updateActivity(state: .inactive)
                case .background:
                    appState = .background
                    liveActivityManager.updateActivity(state: .background)
                @unknown default:
                    break
                }
            }
        }
    }
}

enum AppLifecycleState {
    case active, inactive, background
}
