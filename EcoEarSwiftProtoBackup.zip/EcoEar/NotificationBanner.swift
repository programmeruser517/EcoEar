//
//  NotificationBanner.swift
//  EcoEar
//
//  Created by Peter Pena on 5/28/25.
//

import SwiftUI
import UserNotifications
import ActivityKit

// Define the attributes for the Live Activity
// This is iOS-specific but we'll add comments about Android equivalent
struct EcoEarActivityAttributes: ActivityAttributes {
    // ContentState conforms to Codable to allow updates to the Live Activity
    public struct ContentState: Codable, Hashable {
        var status: String
        var details: String
        var stateColor: String // We'll use a string since ActivityKit doesn't support Color directly
    }
    
    // Static attributes that won't change during the activity
    var appName: String
}
// LiveActivityManager - handles Live Activities with cross-platform compatibility comments
// On Android, this would be implemented using a Foreground Service with a persistent notification
class LiveActivityManager {
    // Keep track of the current activity
    private var currentActivity: Activity<EcoEarActivityAttributes>?
    
    // Flag to track if we've already shown a detailed error message
    private var hasShownDetailedError = false
    
    // Start a new Live Activity or update existing one
    func startActivity(state: AppLifecycleState) {
        // Verify Live Activities support with detailed error messages
        let (supported, errorMessage) = LiveActivitySupportHelper.verifyLiveActivitiesSupport()
        
        guard supported else {
            // Only show detailed error once to avoid console spam
            if !hasShownDetailedError {
                print("Live Activities not supported: \(errorMessage ?? "Unknown error")")
                print("See LiveActivitySupport.swift for setup instructions.")
                hasShownDetailedError = true
            }
            return
        }
        
        // Only start a new activity if we don't already have one
        if currentActivity == nil {
            // Create the initial content state
            let initialContentState = createContentState(for: state)
            
            // Create activity attributes
            let activityAttributes = EcoEarActivityAttributes(appName: "EcoEar")
            
            // Use helper for better error handling
            // Android equivalent: startForeground() with a notification in a Service
            LiveActivitySupportHelper.startActivityWithErrorHandling(
                attributes: activityAttributes,
                contentState: initialContentState
            ) { result in
                switch result {
                case .success(let activity):
                    self.currentActivity = activity
                    print("Started Live Activity with ID: \(activity.id)")
                case .failure(let error):
                    print("Error starting Live Activity: \(error.localizedDescription)")
                    
                    // Check for specific NSSupportsLiveActivities error
                    if error.localizedDescription.contains("NSSupportsLiveActivities") {
                        print("""
                        
                        CONFIGURATION ERROR: Missing NSSupportsLiveActivities key in Info.plist
                        
                        To fix this:
                        1. Open your target settings in Xcode
                        2. Go to the "Info" tab
                        3. Add a new entry with key "NSSupportsLiveActivities" and type "Boolean" set to "YES"
                        
                        Alternatively, see LiveActivitySupport.swift for more detailed setup instructions.
                        """)
                    }
                }
            }
        } else {
            // If we already have an activity, just update it
            updateActivity(state: state)
        }
    }
    
    // Update an existing Live Activity
    func updateActivity(state: AppLifecycleState) {
        guard let activity = currentActivity else {
            // If no activity exists, start one
            startActivity(state: state)
            return
        }
        
        // Create updated content state
        let updatedContentState = createContentState(for: state)
        
        // Update the activity with the new state
        // Android equivalent: updating an existing foreground notification
        Task {
            do {
                await activity.update(using: updatedContentState)
                print("Updated Live Activity with new state: \(state)")
            } catch {
                print("Error updating Live Activity: \(error.localizedDescription)")
                
                // If updating fails, try to restart the activity
                currentActivity = nil
                startActivity(state: state)
            }
        }
    }
    
    // End the Live Activity
    func endActivity() {
        guard let activity = currentActivity else {
            return
        }
        
        // End the activity
        // Android equivalent: stopForeground() and removing the notification
        Task {
            do {
                await activity.end(dismissalPolicy: .immediate)
                print("Ended Live Activity")
                currentActivity = nil
            } catch {
                print("Error ending Live Activity: \(error.localizedDescription)")
            }
        }
        
        // Reset error flag so we can show errors again if needed
        hasShownDetailedError = false
    }
    
    // Helper to create content state based on app state
    private func createContentState(for state: AppLifecycleState) -> EcoEarActivityAttributes.ContentState {
        switch state {
        case .active:
            return EcoEarActivityAttributes.ContentState(
                status: "Active",
                details: "App is currently active - monitoring environment",
                stateColor: "green"
            )
        case .inactive:
            return EcoEarActivityAttributes.ContentState(
                status: "Inactive",
                details: "App is inactive",
                stateColor: "gray"
            )
        case .background:
            return EcoEarActivityAttributes.ContentState(
                status: "Background",
                details: "App is now in background mode - limited activity",
                stateColor: "orange"
            )
        }
    }
}

// Keep the visual banner for in-app state representation
struct NotificationBanner: View {
    var appState: AppLifecycleState
    
    var body: some View {
        HStack {
            Image(systemName: "bell.fill")
            Text(bannerText).font(.headline)
        }
        .foregroundColor(.white)
        .padding()
        .frame(maxWidth: .infinity)
        .background(bannerColor)
        .transition(.move(edge: .top))
        .animation(.easeInOut, value: appState)
    }
    
    var bannerText: String {
        switch appState{
        case .active:
            return "App is currently active - monitoring environment"
        case .background:
            return "App is now in background mode - limited activity"
        case .inactive:
            return "App is inactive"
        }
    }
    
    var bannerColor: Color {
        switch appState {
        case .active:
            return Color.green
        case .background:
            return Color.orange
        case .inactive:
            return Color.gray
        }
    }
}
