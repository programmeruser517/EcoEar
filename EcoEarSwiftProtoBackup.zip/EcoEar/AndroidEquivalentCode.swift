//
//  AndroidEquivalentCode.swift
//  EcoEar
//
//  Created by Peter Pena on 5/30/25.
//

// This file contains sample Android equivalent code for the Live Activity functionality.
// It's provided as a reference for when porting the app to Android.
// This doesn't need to be included in the iOS app, but demonstrates the equivalent Android implementation.

/*

// ANDROID EQUIVALENT IMPLEMENTATION (in Kotlin)

// In your Android Manifest.xml
<service
    android:name=".EcoEarForegroundService"
    android:enabled="true"
    android:exported="false" />

// Create a Foreground Service class
class EcoEarForegroundService : Service() {
    private val NOTIFICATION_ID = 1
    private val CHANNEL_ID = "EcoEarChannel"
    
    // Track current app state
    private var currentState: AppLifecycleState = AppLifecycleState.ACTIVE
    
    enum class AppLifecycleState {
        ACTIVE, INACTIVE, BACKGROUND
    }
    
    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }
    
    override fun onStartCommand(intent: Intent, flags: Int, startId: Int): Int {
        // Get state from intent
        val stateString = intent.getStringExtra("appState") ?: "ACTIVE"
        currentState = AppLifecycleState.valueOf(stateString)
        
        // Update the notification based on state
        startForeground(NOTIFICATION_ID, createNotification(currentState))
        
        return START_STICKY
    }
    
    // Create the notification channel required for Android 8.0+
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "EcoEar Status"
            val descriptionText = "Shows the current status of EcoEar app"
            val importance = NotificationManager.IMPORTANCE_HIGH
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }
    
    // Create notification based on app state
    private fun createNotification(state: AppLifecycleState): Notification {
        val title = "EcoEar: ${state.name}"
        
        val content = when (state) {
            AppLifecycleState.ACTIVE -> "App is currently active - monitoring environment"
            AppLifecycleState.INACTIVE -> "App is inactive"
            AppLifecycleState.BACKGROUND -> "App is now in background mode - limited activity"
        }
        
        // Create intent for when user taps notification
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        
        // Create custom notification layout
        val notificationLayout = RemoteViews(packageName, R.layout.notification_ecoear)
        notificationLayout.setTextViewText(R.id.notification_title, title)
        notificationLayout.setTextViewText(R.id.notification_content, content)
        
        // Set icon color based on state
        val iconColor = when (state) {
            AppLifecycleState.ACTIVE -> Color.GREEN
            AppLifecycleState.INACTIVE -> Color.GRAY
            AppLifecycleState.BACKGROUND -> Color.parseColor("#FFA500") // Orange
        }
        notificationLayout.setInt(R.id.notification_icon, "setColorFilter", iconColor)
        
        // Build and return the notification
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_ear)
            .setStyle(NotificationCompat.DecoratedCustomViewStyle())
            .setCustomContentView(notificationLayout)
            .setOngoing(true) // Make it persistent
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
    }
    
    // Update notification with new state
    fun updateNotification(state: AppLifecycleState) {
        currentState = state
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID, createNotification(state))
    }
    
    override fun onBind(intent: Intent): IBinder? {
        return null
    }
    
    override fun onDestroy() {
        super.onDestroy()
        stopForeground(true)
    }
}

// Usage in your activity/app:

// Start the service when app appears
private fun startEcoEarService() {
    val serviceIntent = Intent(this, EcoEarForegroundService::class.java)
    serviceIntent.putExtra("appState", "ACTIVE")
    
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        startForegroundService(serviceIntent)
    } else {
        startService(serviceIntent)
    }
}

// Update service when app state changes
private fun updateEcoEarService(state: String) {
    val serviceIntent = Intent(this, EcoEarForegroundService::class.java)
    serviceIntent.putExtra("appState", state)
    
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        startForegroundService(serviceIntent)
    } else {
        startService(serviceIntent)
    }
}

// Stop service when app closes
private fun stopEcoEarService() {
    val serviceIntent = Intent(this, EcoEarForegroundService::class.java)
    stopService(serviceIntent)
}

*/

