//
//  EcoEarLiveActivity.swift
//  EcoEar
//
//  Created by Peter Pena on 5/30/25.
//

import SwiftUI
import WidgetKit
import ActivityKit

// This file defines how the Live Activity looks
// Android equivalent would be a custom RemoteViews layout for a foreground notification

struct EcoEarLiveActivityView: View {
    let context: ActivityViewContext<EcoEarActivityAttributes>
    
    var body: some View {
        HStack {
            // App icon or symbol
            Image(systemName: "ear")
                .font(.title)
                .foregroundColor(stateColor)
                .padding(.horizontal)
            
            VStack(alignment: .leading) {
                // Status text
                Text("EcoEar: \(context.state.status)")
                    .font(.headline)
                    .foregroundColor(.primary)
                
                // Details text
                Text(context.state.details)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            
            Spacer()
        }
        .padding()
        .background(Color.white.opacity(0.8))
        .cornerRadius(15)
        .shadow(radius: 3)
    }
    
    // Convert string color name to Color
    private var stateColor: Color {
        switch context.state.stateColor {
        case "green":
            return .green
        case "orange":
            return .orange
        case "gray":
            return .gray
        default:
            return .blue
        }
    }
}

// Define how the Live Activity should be displayed on the Lock Screen
struct EcoEarLiveActivityLockScreenView: View {
    let context: ActivityViewContext<EcoEarActivityAttributes>
    
    var body: some View {
        VStack {
            // App name with status
            HStack {
                Image(systemName: "ear")
                    .foregroundColor(stateColor)
                Text("EcoEar: \(context.state.status)")
                    .font(.headline)
                    .bold()
            }
            .padding(.bottom, 2)
            
            // Status details
            Text(context.state.details)
                .font(.subheadline)
                .multilineTextAlignment(.center)
        }
        .padding()
        .background(Color.black.opacity(0.1))
        .cornerRadius(15)
    }
    
    // Convert string color name to Color
    private var stateColor: Color {
        switch context.state.stateColor {
        case "green":
            return .green
        case "orange":
            return .orange
        case "gray":
            return .gray
        default:
            return .blue
        }
    }
}

@available(iOS 16.1, *)
struct EcoEarLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: EcoEarActivityAttributes.self) { context in
            // Lock screen/banner UI
            EcoEarLiveActivityLockScreenView(context: context)
        } dynamicIsland: { context in
            // Dynamic Island UI
            DynamicIsland {
                // Expanded UI
                DynamicIslandExpandedRegion(.leading) {
                    Image(systemName: "ear")
                        .foregroundColor(stateColor(context.state.stateColor))
                }
                
                DynamicIslandExpandedRegion(.center) {
                    Text("EcoEar: \(context.state.status)")
                        .font(.headline)
                }
                
                DynamicIslandExpandedRegion(.trailing) {
                    Image(systemName: "waveform")
                        .foregroundColor(stateColor(context.state.stateColor))
                }
                
                DynamicIslandExpandedRegion(.bottom) {
                    Text(context.state.details)
                        .font(.subheadline)
                        .padding(.top, 4)
                }
            } compactLeading: {
                // Compact leading UI
                Image(systemName: "ear")
                    .foregroundColor(stateColor(context.state.stateColor))
            } compactTrailing: {
                // Compact trailing UI
                Text(context.state.status)
                    .foregroundColor(stateColor(context.state.stateColor))
            } minimal: {
                // Minimal UI
                Image(systemName: "ear")
                    .foregroundColor(stateColor(context.state.stateColor))
            }
        }
    }
    
    // Helper function to convert string to Color
    private func stateColor(_ colorName: String) -> Color {
        switch colorName {
        case "green":
            return .green
        case "orange":
            return .orange
        case "gray":
            return .gray
        default:
            return .blue
        }
    }
}

